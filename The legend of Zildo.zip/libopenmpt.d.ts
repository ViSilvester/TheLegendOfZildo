export var Module;
export function UTF8ToString(v1, v2) { };
export function writeAsciiToMemory(v1, v2) { }